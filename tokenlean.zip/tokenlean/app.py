"""Streamlit demo + metrics dashboard. Run: streamlit run app.py"""
import pandas as pd
import streamlit as st

from tokenlean.config import RUNS_DIR
from tokenlean.evaluate import run_eval
from tokenlean.metrics import load_rows, summarize
from tokenlean.pipeline import build_pipeline

st.set_page_config(page_title="TokenLean", layout="wide")
st.title("TokenLean: cost-optimized RAG assistant")


@st.cache_resource
def pipe():
    return build_pipeline()


p = pipe()
st.caption(f"Mode: {'LIVE Anthropic API' if p.llm.live else 'MOCK (offline demo; set ANTHROPIC_API_KEY for live)'}")
tab_ask, tab_dash, tab_eval = st.tabs(["Ask", "Metrics dashboard", "Evaluation"])

with tab_ask:
    q = st.text_input("Question about the Nimbus Cloud knowledge base", "What is the monthly price of the Pro plan?")
    mode = st.radio("Pipeline", ["optimized", "baseline", "compare both"], horizontal=True)
    if st.button("Ask") and q:
        modes = ["baseline", "optimized"] if mode == "compare both" else [mode]
        cols = st.columns(len(modes))
        for col, m in zip(cols, modes):
            ans = getattr(p, m)(q)
            mt = ans.metrics
            with col:
                st.subheader(m.capitalize())
                st.success(ans.text)
                c1, c2, c3 = st.columns(3)
                c1.metric("Tokens in", mt.tokens_in)
                c2.metric("Context tokens", mt.retrieval_tokens_after, f"from {mt.retrieval_tokens_before}")
                c3.metric("Cost (USD)", f"{mt.cost_usd:.6f}")
                st.caption(f"model: {mt.model} ({mt.route_reason}) | cache read: {mt.cache_read} | escalated: {mt.escalated}")
                with st.expander("Context sent to the model"):
                    st.text(ans.context)
                for a in ans.alerts:
                    st.warning(a)

with tab_dash:
    rows = load_rows()
    if not rows:
        st.info("No requests logged yet. Ask a question or run the evaluation.")
    else:
        df = pd.DataFrame(rows)
        for mode_name, g in df.groupby("mode"):
            s = summarize(g.to_dict("records"))
            st.subheader(mode_name)
            c = st.columns(5)
            c[0].metric("Requests", s["n"])
            c[1].metric("Avg tokens in", f"{s['avg_tokens_in']:.0f}")
            c[2].metric("Cache hit rate", f"{s['cache_hit_rate']:.0%}")
            c[3].metric("Cost / 1k queries", f"${s['cost_per_1k']:.2f}")
            c[4].metric("Small-model share", f"{s['small_model_share']:.0%}")
            for a in s["alerts"]:
                st.warning(a)
        df["req"] = df.groupby("mode").cumcount() + 1
        st.line_chart(df.pivot(index="req", columns="mode", values="tokens_in"), y_label="input tokens")
        st.line_chart(df.pivot(index="req", columns="mode", values="cost_usd"), y_label="cost (USD)")
        st.dataframe(df.drop(columns=["ts"]), width="stretch")

with tab_eval:
    if st.button("Run baseline vs optimized evaluation"):
        run_eval()
    md = RUNS_DIR / "results.md"
    st.markdown(md.read_text() if md.exists() else "Run the evaluation to see results.")
