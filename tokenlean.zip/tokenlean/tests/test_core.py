import os

os.environ["TOKENLEAN_MODE"] = "mock"

from tokenlean.compress import compress
from tokenlean.config import CHUNK_SENTENCES, CONTEXT_TOKEN_CAP, DOCS_DIR, LARGE_MODEL, SMALL_MODEL
from tokenlean.metrics import Tracker
from tokenlean.pipeline import Pipeline
from tokenlean.llm import MockLLM
from tokenlean.pruning import prune
from tokenlean.retrieval import Retriever, load_chunks
from tokenlean.router import route


def make(tmp_path):
    r = Retriever(load_chunks(DOCS_DIR, CHUNK_SENTENCES))
    return r, Pipeline(r, MockLLM(), Tracker(tmp_path / "m.jsonl"))


def test_compress_keeps_urls_and_code():
    s = "Please could you check https://example.com/a  and `code  here` please"
    out = compress(s)
    assert "https://example.com/a" in out and "`code  here`" in out
    assert "please" not in out.lower()


def test_router():
    assert route("What is the price of Pro?")[0] == SMALL_MODEL
    assert route("Compare Starter and Pro backups")[0] == LARGE_MODEL


def test_prune_respects_cap_and_reduces(tmp_path):
    r, _ = make(tmp_path)
    q = "What is the monthly price of the Pro plan?"
    pr = prune(q, r.search(q, 20), r)
    assert pr.tokens_after <= CONTEXT_TOKEN_CAP
    assert pr.tokens_after < pr.tokens_before


def test_optimized_uses_fewer_tokens_than_baseline(tmp_path):
    _, p = make(tmp_path)
    q = "What is the monthly price of the Pro plan?"
    b = p.baseline(q).metrics
    o1 = p.optimized(q).metrics
    o2 = p.optimized(q).metrics
    assert o1.tokens_in < b.tokens_in
    assert o2.cache_read > 0  # second call hits the (simulated) cache
    assert "99" in p.optimized(q).text
