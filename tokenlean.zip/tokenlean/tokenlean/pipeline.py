from dataclasses import dataclass, field

from .compress import compress
from .config import (CONTEXT_TOKEN_CAP, DOCS_DIR, CHUNK_SENTENCES, LARGE_MODEL, MAX_OUTPUT_TOKENS, MIN_HITS,
                     TOP_K_FETCH, TOP_K_KEEP)
from .llm import LLMResult, get_llm
from .metrics import RequestMetrics, Tracker, cost_usd
from .pruning import prune
from .prompts import STATIC_SYS, build_user
from .retrieval import Retriever, load_chunks
from .router import route
from .tokens import count_tokens


@dataclass
class Answer:
    text: str
    context: str
    metrics: RequestMetrics
    alerts: list[str] = field(default_factory=list)


class Pipeline:
    """Q -> Retrieve -> Prune -> Cache -> Route -> Compress -> LLM -> Measure"""

    def __init__(self, retriever: Retriever, llm, tracker: Tracker | None = None):
        self.r, self.llm, self.tracker = retriever, llm, tracker or Tracker()

    # ---- naive baseline: top-20 chunks, no pruning, no cache, always the big model
    def baseline(self, q: str) -> Answer:
        hits = self.r.search(q, TOP_K_FETCH, MIN_HITS)
        ctx = "\n".join(f"[{self.r.chunks[i].source}] {self.r.chunks[i].text}" for i, _ in hits)
        before = sum(count_tokens(self.r.chunks[i].text) for i, _ in hits)
        res = self.llm.complete(LARGE_MODEL, STATIC_SYS, build_user(ctx, q), False, MAX_OUTPUT_TOKENS)
        return self._finish("baseline", q, ctx, [(LARGE_MODEL, res)], "always-large", before, count_tokens(ctx), False)

    # ---- optimized: prune -> cache -> route -> compress -> (escalate on failure)
    def optimized(self, q: str) -> Answer:
        hits = self.r.search(q, TOP_K_FETCH, MIN_HITS)
        pr = prune(q, hits, self.r)
        question = compress(q)
        model, reason = route(question)
        calls = [(model, self.llm.complete(model, STATIC_SYS, build_user(pr.context, question), True, MAX_OUTPUT_TOKENS))]
        escalated = False
        if "INSUFFICIENT_CONTEXT" in calls[0][1].text and model != LARGE_MODEL:
            # safety guard: retry once on the stronger model with more context
            escalated = True
            hits = self.r.search(q, TOP_K_FETCH + 10, MIN_HITS)
            pr = prune(q, hits, self.r, keep=TOP_K_KEEP + 4, cap=int(CONTEXT_TOKEN_CAP * 1.5))
            calls.append((LARGE_MODEL, self.llm.complete(LARGE_MODEL, STATIC_SYS, build_user(pr.context, question), True, MAX_OUTPUT_TOKENS)))
        return self._finish("optimized", q, pr.context, calls, reason, pr.tokens_before, pr.tokens_after, escalated)

    def _finish(self, mode, q, ctx, calls: list[tuple[str, LLMResult]], reason, before, after, escalated) -> Answer:
        inp = sum(r.input_tokens for _, r in calls)
        cw = sum(r.cache_write_tokens for _, r in calls)
        cr = sum(r.cache_read_tokens for _, r in calls)
        out = sum(r.output_tokens for _, r in calls)
        cost = sum(cost_usd(m, r.input_tokens, r.cache_write_tokens, r.cache_read_tokens, r.output_tokens) for m, r in calls)
        m = RequestMetrics(
            mode=mode, question=q, model=calls[-1][0], route_reason=reason,
            tokens_in=inp + cw + cr, tokens_in_uncached=inp, cache_write=cw, cache_read=cr, tokens_out=out,
            latency_ms=sum(r.latency_ms for _, r in calls), retrieval_tokens_before=before,
            retrieval_tokens_after=after, cost_usd=cost, escalated=escalated, live=self.llm.live,
        )
        return Answer(calls[-1][1].text, ctx, m, self.tracker.log(m))


def build_pipeline(tracker: Tracker | None = None) -> Pipeline:
    return Pipeline(Retriever(load_chunks(DOCS_DIR, CHUNK_SENTENCES)), get_llm(), tracker)
