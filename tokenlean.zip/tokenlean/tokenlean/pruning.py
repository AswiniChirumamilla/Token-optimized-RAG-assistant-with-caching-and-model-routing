import math
import re
from dataclasses import dataclass

from .config import CONTEXT_TOKEN_CAP, DEDUPE_SIM, TOP_K_KEEP
from .retrieval import Retriever, split_sentences
from .tokens import count_tokens

STOP = set(
    "a an the of to in on for is are was were be been do does did what which who when where why how many much "
    "can i my our we you your it its this that with from by or and as at if than then there any so take".split()
)


def _stem(w: str) -> str:
    for suf in ("ations", "ation", "ing", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            return w[: -len(suf)]
    return w


def terms(text: str) -> set[str]:
    return {_stem(w) for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP}


def sentence_trim(text: str, qterms: set[str]) -> str:
    """Keep only the sentences that best overlap the query terms."""
    sents = split_sentences(text)
    scored = [(len(qterms & terms(s)), s) for s in sents]
    best = max(sc for sc, _ in scored)
    if best == 0:
        return sents[0]
    floor = max(1, math.ceil(best / 2))
    return " ".join(s for sc, s in scored if sc >= floor)


@dataclass
class Pruned:
    context: str
    chunk_ids: list[int]
    tokens_before: int
    tokens_after: int


def prune(query: str, hits: list[tuple[int, float]], r: Retriever,
          keep: int = TOP_K_KEEP, cap: int = CONTEXT_TOKEN_CAP, thr: float = DEDUPE_SIM) -> Pruned:
    before = sum(count_tokens(r.chunks[i].text) for i, _ in hits)
    kept: list[int] = []
    for i, _ in hits:  # dedupe near-duplicates (cosine > thr)
        if all(r.sim(i, j) <= thr for j in kept):
            kept.append(i)
    qt = terms(query)
    parts, used, total = [], [], 0
    for i in kept[:keep]:
        text = f"[{r.chunks[i].source}] {sentence_trim(r.chunks[i].text, qt)}"
        n = count_tokens(text)
        if total + n > cap:  # hard cap
            continue
        parts.append(text)
        used.append(i)
        total += n
    return Pruned("\n".join(parts), used, before, total)
