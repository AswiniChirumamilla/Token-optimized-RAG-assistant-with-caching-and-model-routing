import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")


def split_sentences(text: str) -> list[str]:
    return [s.strip() for s in SENT_SPLIT.split(text.strip()) if s.strip()]


@dataclass
class Chunk:
    id: int
    source: str
    text: str


def load_chunks(doc_dir: Path, sentences_per_chunk: int = 4) -> list[Chunk]:
    chunks: list[Chunk] = []
    for path in sorted(Path(doc_dir).glob("*.md")):
        body = "\n".join(l for l in path.read_text().splitlines() if not l.startswith("#"))
        sents = split_sentences(body)
        for i in range(0, len(sents), sentences_per_chunk):
            chunks.append(Chunk(len(chunks), path.stem, " ".join(sents[i : i + sentences_per_chunk])))
    return chunks


class Retriever:
    """TF-IDF retriever (zero downloads, runs anywhere). Swap for dense embeddings by keeping the same interface."""

    def __init__(self, chunks: list[Chunk]):
        self.chunks = chunks
        self.vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
        self.matrix = self.vec.fit_transform([c.text for c in chunks])  # rows are L2-normalised

    def search(self, query: str, k: int = 20, min_hits: int = 5) -> list[tuple[int, float]]:
        q = self.vec.transform([query])
        scores = (self.matrix @ q.T).toarray().ravel()
        order = np.argsort(-scores)
        hits = [(int(i), float(scores[i])) for i in order[:k] if scores[i] > 0]
        if len(hits) < min_hits:  # token-diet rule: too few relevant chunks -> fetch more
            hits = [(int(i), float(scores[i])) for i in order[: max(k, min_hits)]]
        return hits

    def sim(self, i: int, j: int) -> float:
        return float(self.matrix[i].multiply(self.matrix[j]).sum())
