"""TokenLean: a cost-optimized RAG assistant (retrieval pruning, prompt caching, model routing)."""
