def count_tokens(text: str) -> int:
    """Cheap estimate (~4 chars per token). Live mode uses the API's real usage numbers."""
    return max(1, round(len(text) / 4)) if text else 0
