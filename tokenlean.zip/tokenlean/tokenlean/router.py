import re

from .config import LARGE_MODEL, SMALL_MODEL

_COMPLEX = re.compile(r"\b(why|compare|comparison|difference|trade-?offs?|should|recommend|explain|pros|cons|design)\b", re.I)
_SIMPLE = re.compile(r"^(what|which|when|who|how many|how much|how long|list|name|is|are|does|do)\b", re.I)


def route(question: str) -> tuple[str, str]:
    """Cheap-first routing: lookup/extract style -> small model, reasoning style -> large model."""
    if _COMPLEX.search(question):
        return LARGE_MODEL, "complex"
    if _SIMPLE.match(question.strip()) and len(question.split()) <= 18:
        return SMALL_MODEL, "simple"
    return LARGE_MODEL, "default"
