import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from .config import (ALERT_CACHE_HIT_RATE, ALERT_CONTEXT_TOKENS, CACHE_READ_MULT, CACHE_WRITE_MULT,
                     METRICS_FILE, PRICES)


def cost_usd(model: str, inp: int, cache_write: int, cache_read: int, out: int) -> float:
    p = PRICES[model]
    in_cost = (inp + CACHE_WRITE_MULT * cache_write + CACHE_READ_MULT * cache_read) * p["in"]
    return (in_cost + out * p["out"]) / 1_000_000


@dataclass
class RequestMetrics:
    mode: str                  # baseline | optimized
    question: str
    model: str
    route_reason: str
    tokens_in: int             # total input incl. cached
    tokens_in_uncached: int
    cache_write: int
    cache_read: int
    tokens_out: int
    latency_ms: float
    retrieval_tokens_before: int
    retrieval_tokens_after: int
    cost_usd: float
    escalated: bool
    live: bool
    ts: float = 0.0


class Tracker:
    def __init__(self, path: Path = METRICS_FILE):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def reset(self):
        self.path.write_text("")

    def log(self, m: RequestMetrics) -> list[str]:
        m.ts = time.time()
        with self.path.open("a") as f:
            f.write(json.dumps(asdict(m)) + "\n")
        alerts = []
        if m.retrieval_tokens_after > ALERT_CONTEXT_TOKENS:
            alerts.append(f"Context {m.retrieval_tokens_after} tokens > {ALERT_CONTEXT_TOKENS}: investigate retrieval")
        return alerts


def load_rows(path: Path = METRICS_FILE) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]


def summarize(rows: list[dict]) -> dict:
    n = len(rows)
    if not n:
        return {}
    avg = lambda k: sum(r[k] for r in rows) / n
    out = {
        "n": n,
        "avg_tokens_in": avg("tokens_in"),
        "avg_tokens_out": avg("tokens_out"),
        "avg_latency_ms": avg("latency_ms"),
        "avg_ctx_before": avg("retrieval_tokens_before"),
        "avg_ctx_after": avg("retrieval_tokens_after"),
        "cache_hit_rate": sum(1 for r in rows if r["cache_read"] > 0) / n,
        "cost_per_1k": avg("cost_usd") * 1000,
        "small_model_share": sum(1 for r in rows if "haiku" in r["model"]) / n,
        "escalation_rate": sum(1 for r in rows if r["escalated"]) / n,
    }
    out["alerts"] = []
    if out["cache_hit_rate"] < ALERT_CACHE_HIT_RATE and rows[0]["mode"] == "optimized":
        out["alerts"].append(f"Cache hit rate {out['cache_hit_rate']:.0%} < {ALERT_CACHE_HIT_RATE:.0%}: check static block design")
    return out
