import json

from .config import EVAL_FILE, RUNS_DIR
from .llm import get_llm
from .metrics import Tracker, load_rows, summarize
from .pipeline import Pipeline, build_pipeline
from .retrieval import Retriever, load_chunks
from .config import DOCS_DIR, CHUNK_SENTENCES


def score(answer: str, keywords: list[str]) -> float:
    a = answer.lower()
    return sum(k.lower() in a for k in keywords) / len(keywords)


def run_eval() -> dict:
    cases = json.loads(EVAL_FILE.read_text())
    tracker = Tracker()
    tracker.reset()
    retriever = Retriever(load_chunks(DOCS_DIR, CHUNK_SENTENCES))
    results = {}
    for mode in ("baseline", "optimized"):
        pipe = Pipeline(retriever, get_llm(), tracker)  # fresh LLM => fresh cache state per mode
        scores = []
        for c in cases:
            ans = getattr(pipe, mode)(c["q"])
            scores.append(score(ans.text, c["keywords"]))
        rows = [r for r in load_rows() if r["mode"] == mode]
        s = summarize(rows)
        s["quality"] = sum(scores) / len(scores)
        s["live"] = rows[0]["live"]
        results[mode] = s
    results["n_questions"] = len(cases)
    RUNS_DIR.mkdir(exist_ok=True)
    (RUNS_DIR / "results.json").write_text(json.dumps(results, indent=2))
    (RUNS_DIR / "results.md").write_text(to_markdown(results))
    return results


def _pct(b, o):
    return f"{(o - b) / b * 100:+.0f}%" if b else "n/a"


def to_markdown(r: dict) -> str:
    b, o = r["baseline"], r["optimized"]
    live = o["live"]
    lat = (lambda k: f"{k:.0f} ms") if live else (lambda k: "n/a (mock)")
    lines = [
        f"Eval: {r['n_questions']} questions | mode: {'LIVE API' if live else 'MOCK (offline; tokens estimated, cost uses placeholder prices)'}",
        "",
        "| Metric | Baseline | Optimized | Change |",
        "|---|---|---|---|",
        f"| Avg input tokens / query | {b['avg_tokens_in']:.0f} | {o['avg_tokens_in']:.0f} | {_pct(b['avg_tokens_in'], o['avg_tokens_in'])} |",
        f"| Avg retrieved-context tokens | {b['avg_ctx_after']:.0f} | {o['avg_ctx_after']:.0f} | {_pct(b['avg_ctx_after'], o['avg_ctx_after'])} |",
        f"| Avg output tokens / query | {b['avg_tokens_out']:.0f} | {o['avg_tokens_out']:.0f} | {_pct(b['avg_tokens_out'], o['avg_tokens_out'])} |",
        f"| Cache hit rate | {b['cache_hit_rate']:.0%} | {o['cache_hit_rate']:.0%} | n/a |",
        f"| Avg latency | {lat(b['avg_latency_ms'])} | {lat(o['avg_latency_ms'])} | {_pct(b['avg_latency_ms'], o['avg_latency_ms']) if live else 'n/a'} |",
        f"| Cost per 1,000 queries | ${b['cost_per_1k']:.2f} | ${o['cost_per_1k']:.2f} | {_pct(b['cost_per_1k'], o['cost_per_1k'])} |",
        f"| Answer quality (keyword score) | {b['quality']:.2f} | {o['quality']:.2f} | {o['quality'] - b['quality']:+.2f} |",
        f"| Routed to small model | {b['small_model_share']:.0%} | {o['small_model_share']:.0%} | n/a |",
        f"| Escalation rate | n/a | {o['escalation_rate']:.0%} | n/a |",
    ]
    for a in o.get("alerts", []):
        lines.append(f"\n> ALERT: {a}")
    return "\n".join(lines)


if __name__ == "__main__":
    print(to_markdown(run_eval()))
