import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOCS_DIR = ROOT / "data" / "docs"
EVAL_FILE = ROOT / "data" / "eval.json"
RUNS_DIR = ROOT / "runs"
METRICS_FILE = RUNS_DIR / "metrics.jsonl"

# Models (override with env vars if your account uses different model names)
SMALL_MODEL = os.getenv("SMALL_MODEL", "claude-haiku-5-5")
LARGE_MODEL = os.getenv("LARGE_MODEL", "claude-sonnet-5-5")

# USD per 1M tokens.
# !! PLACEHOLDER VALUES: check https://www.anthropic.com/pricing and update before quoting any cost number !!
PRICES = {
    SMALL_MODEL: {"in": 1.00, "out": 5.00},
    LARGE_MODEL: {"in": 3.00, "out": 15.00},
}
CACHE_WRITE_MULT = 1.25  # cache writes cost more than normal input tokens
CACHE_READ_MULT = 0.10   # cache reads cost much less

# Retrieval / pruning (token-diet defaults)
CHUNK_SENTENCES = 4
TOP_K_FETCH = 20
TOP_K_KEEP = 6
CONTEXT_TOKEN_CAP = 1200
DEDUPE_SIM = 0.85
MIN_HITS = 5
MAX_OUTPUT_TOKENS = 300

# Alerts
ALERT_CONTEXT_TOKENS = 1500
ALERT_CACHE_HIT_RATE = 0.70
