import re

_FILLERS = [
    r"\bplease\b", r"\bkindly\b", r"\bcould you\b", r"\bcan you\b", r"\bwould you\b",
    r"\bi would like to know\b", r"\bi want to know\b", r"\btell me\b", r"\bjust\b",
]
_PROTECTED = re.compile(r"(`[^`]*`|https?://\S+|\S+@\S+)")


def compress(text: str) -> str:
    """Last-mile prose compression. Never touches code spans, URLs or emails."""
    out = []
    for i, part in enumerate(_PROTECTED.split(text)):
        if i % 2 == 1:  # protected segment
            out.append(part)
            continue
        for f in _FILLERS:
            part = re.sub(f, "", part, flags=re.I)
        out.append(re.sub(r"[ \t]{2,}", " ", part))
    return "".join(out).strip()
