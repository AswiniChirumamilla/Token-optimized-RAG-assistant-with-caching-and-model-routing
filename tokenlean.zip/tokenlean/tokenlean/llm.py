import os
import re
import time
from dataclasses import dataclass

from .pruning import terms
from .retrieval import split_sentences
from .tokens import count_tokens


@dataclass
class LLMResult:
    text: str
    input_tokens: int       # uncached input tokens
    output_tokens: int
    cache_write_tokens: int
    cache_read_tokens: int
    latency_ms: float


class LiveLLM:
    """Real Anthropic API calls with prompt caching on the static system block."""
    live = True

    def __init__(self):
        import anthropic
        self.client = anthropic.Anthropic()

    def complete(self, model: str, system: str, user: str, cache_system: bool = True, max_tokens: int = 300) -> LLMResult:
        block = {"type": "text", "text": system}
        if cache_system:
            block["cache_control"] = {"type": "ephemeral"}
        t0 = time.perf_counter()
        resp = self.client.messages.create(
            model=model, max_tokens=max_tokens, system=[block],
            messages=[{"role": "user", "content": user}],
        )
        ms = (time.perf_counter() - t0) * 1000
        u = resp.usage
        text = "".join(b.text for b in resp.content if b.type == "text").strip()
        return LLMResult(
            text, u.input_tokens, u.output_tokens,
            getattr(u, "cache_creation_input_tokens", 0) or 0,
            getattr(u, "cache_read_input_tokens", 0) or 0, ms,
        )


class MockLLM:
    """Offline stand-in: extractive 'answers' + simulated cache accounting.
    Token counts are estimates, latency is not meaningful. Use LiveLLM for real numbers."""
    live = False

    def __init__(self):
        self._cached: set[int] = set()

    def complete(self, model: str, system: str, user: str, cache_system: bool = True, max_tokens: int = 300) -> LLMResult:
        t0 = time.perf_counter()
        ctx, _, q = user.partition("\n\nQuestion:")
        ctx = re.sub(r"\[[a-z_]+\]\s*", "", ctx.replace("Context:\n", ""))
        qt = terms(q)
        sents = list(dict.fromkeys(s for s in split_sentences(ctx) if not s.endswith("?")))  # drop questions + exact duplicates
        scored = sorted(((len(qt & terms(s)), -i, s) for i, s in enumerate(sents)), reverse=True)
        best = scored[0][0] if scored else 0
        top = [s for sc, _, s in scored[:2] if sc > 0 and sc >= best]  # only the best-matching sentence(s)
        text = " ".join(top) if top else "INSUFFICIENT_CONTEXT"

        sys_tok, user_tok = count_tokens(system), count_tokens(user)
        write = read = 0
        inp = user_tok
        if cache_system:
            h = hash(system)
            if h in self._cached:
                read = sys_tok
            else:
                write = sys_tok
                self._cached.add(h)
        else:
            inp += sys_tok
        return LLMResult(text, inp, count_tokens(text), write, read, (time.perf_counter() - t0) * 1000)


def get_llm():
    if os.getenv("ANTHROPIC_API_KEY") and os.getenv("TOKENLEAN_MODE", "auto") != "mock":
        return LiveLLM()
    return MockLLM()
