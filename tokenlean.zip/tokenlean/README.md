# TokenLean: cost-optimized RAG assistant

A RAG pipeline that treats **tokens as a budget**. It applies retrieval pruning, prompt caching, cheap-first model
routing and last-mile compression, then **measures** the effect against a naive baseline with an eval harness and a
metrics dashboard.

```
Q -> Retrieve -> Prune -> Cache -> Route -> Compress -> LLM -> Measure
```

| Stage | What it does | File |
|---|---|---|
| Retrieve | TF-IDF top-20 chunks (auto-fetches more if <5 relevant) | `retrieval.py` |
| Prune | dedupe near-duplicates (cos > 0.85) -> sentence-trim to query-relevant sentences -> top-6 -> hard 1,200-token cap | `pruning.py` |
| Cache | static system block marked `cache_control: ephemeral`; dynamic context + user input uncached | `llm.py`, `prompts.py` |
| Route | lookup/extract questions -> small model; reasoning questions -> large model; **escalate** to large model with more context if the answer is `INSUFFICIENT_CONTEXT` | `router.py`, `pipeline.py` |
| Compress | strips filler words from the question; never touches code spans, URLs or emails | `compress.py` |
| Measure | per-request tokens, cache hit, cost, latency, context before/after, alerts -> `runs/metrics.jsonl` | `metrics.py` |
| Evaluate | baseline vs optimized on 14 questions, writes `runs/results.md` | `evaluate.py` |

**Baseline** = top-20 chunks unpruned, no caching, always the large model.

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python main.py eval                    # baseline vs optimized table
python main.py ask "What is the monthly price of the Pro plan?"
streamlit run app.py                   # demo + metrics dashboard
pytest -q                              # unit tests
```

Docker: `docker build -t tokenlean . && docker run -p 8501:8501 -e ANTHROPIC_API_KEY=... tokenlean`

## Mock mode vs live mode (read this before quoting numbers)

- **No API key -> MOCK mode.** An offline extractive stand-in answers the questions. Token counts are estimates
  (~4 chars/token), cache hits are simulated, latency is *not* reported. This proves the pipeline works and shows
  token reduction on this corpus, but it is **not** a real LLM cost or quality measurement.
- **`export ANTHROPIC_API_KEY=...` -> LIVE mode.** Real calls; token counts, cache reads/writes and latency come from
  the API `usage` field. **Only live-mode results should go on your resume.**
- Update `PRICES` in `tokenlean/config.py` (they are placeholders) and, if needed, the model names (`SMALL_MODEL`, `LARGE_MODEL`).
- Prompt caching only activates when the static block is longer than the model's minimum cacheable length. If your
  live cache hit rate shows 0%, grow `STATIC_SYS` (schemas, few-shot examples) in `prompts.py`.

## Getting results you can defend

1. Set your key, run `python main.py eval` and keep `runs/results.md`.
2. Replace the toy corpus in `data/docs/` with your own documents and write 30-50 questions in `data/eval.json`
   (`keywords` = strings a correct answer must contain). The sample corpus is a fictional cloud-hosting FAQ.
3. Quality here is keyword matching: simple and reproducible, but crude. For a stronger eval add an LLM-as-judge
   rubric and spot-check by hand.
4. Report the test-set size and any quality trade-off next to your savings numbers.

## Project layout

```
tokenlean/        config, retrieval, pruning, compress, router, prompts, llm, metrics, pipeline, evaluate
app.py            Streamlit demo + dashboard + eval tab
main.py           CLI (ask / eval)
data/docs/        sample knowledge base      data/eval.json   eval questions
tests/            pytest suite               .github/workflows/ci.yml   CI (tests + mock eval)
```

## Ideas to extend

- Dense retrieval: implement `Retriever` with sentence-transformers + FAISS (keep `search()` and `sim()`).
- Smarter router: a small classifier or the small model itself deciding difficulty.
- Structured conversation state (facts / constraints / open tasks) for multi-turn chat.
- Batch the eval through the Message Batches API for cheaper evaluation runs.

## Limitations

TF-IDF retrieval is lexical; the heuristic router is rule-based; keyword scoring is coarse; the sample corpus is tiny.
