"""CLI: python main.py ask "question" | python main.py eval"""
import argparse

from tokenlean.evaluate import run_eval, to_markdown
from tokenlean.pipeline import build_pipeline


def main():
    ap = argparse.ArgumentParser(prog="tokenlean")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("ask", help="ask one question")
    a.add_argument("question")
    a.add_argument("--baseline", action="store_true", help="use the naive baseline pipeline")
    sub.add_parser("eval", help="run baseline vs optimized evaluation")
    args = ap.parse_args()

    if args.cmd == "ask":
        pipe = build_pipeline()
        ans = (pipe.baseline if args.baseline else pipe.optimized)(args.question)
        m = ans.metrics
        print(f"\nAnswer: {ans.text}\n")
        print(f"model={m.model} ({m.route_reason}) | tokens in={m.tokens_in} out={m.tokens_out} "
              f"| context {m.retrieval_tokens_before}->{m.retrieval_tokens_after} | cache_read={m.cache_read} "
              f"| cost=${m.cost_usd:.6f} | {'LIVE' if m.live else 'MOCK'}")
        for al in ans.alerts:
            print("ALERT:", al)
    else:
        print(to_markdown(run_eval()))


if __name__ == "__main__":
    main()
