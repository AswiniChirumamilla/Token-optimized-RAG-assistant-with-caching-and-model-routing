Eval: 14 questions | mode: MOCK (offline; tokens estimated, cost uses placeholder prices)

| Metric | Baseline | Optimized | Change |
|---|---|---|---|
| Avg input tokens / query | 1173 | 425 | -64% |
| Avg retrieved-context tokens | 922 | 172 | -81% |
| Avg output tokens / query | 25 | 24 | -5% |
| Cache hit rate | 0% | 93% | n/a |
| Avg latency | n/a (mock) | n/a (mock) | n/a |
| Cost per 1,000 queries | $3.90 | $0.46 | -88% |
| Answer quality (keyword score) | 1.00 | 1.00 | +0.00 |
| Routed to small model | 0% | 86% | n/a |
| Escalation rate | n/a | 0% | n/a |